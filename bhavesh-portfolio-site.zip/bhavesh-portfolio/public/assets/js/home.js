(()=>{const d=document,$=s=>d.querySelector(s),$$=s=>[...d.querySelectorAll(s)],rm=matchMedia("(prefers-reduced-motion: reduce)").matches;const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add("in");io.unobserve(x.target)}}),{threshold:.12});
/* hero scanner: follows the pointer, drifts on its own when idle */
const lns=$$(".ln"),hero=$("#hero");let last=-1e4;
const aim=(x,y)=>lns.forEach(l=>{const r=l.getBoundingClientRect();l.style.setProperty("--mx",x-r.left+"px");l.style.setProperty("--my",y-r.top+"px")});
hero.addEventListener("pointermove",e=>{last=performance.now();aim(e.clientX,e.clientY)});
if(rm){const a=lns[0].getBoundingClientRect();aim(a.left+a.width/2,a.bottom)}
else(function lp(t){if(t-last>2200){const a=lns[0].getBoundingClientRect(),k=t/1700;aim(a.left+a.width*(.5+.5*Math.sin(k)),a.top+a.height*(1+.7*Math.sin(k*1.3)))}requestAnimationFrame(lp)})(0);
/* role swapper */
const W=["Security researcher","Bug bounty hunter","Web app security","Linux & Windows admin","CTF player"],rl=$("#role");let wi=0;
if(!rm)setInterval(()=>{wi=(wi+1)%W.length;const s=d.createElement("span");s.className="ht";s.textContent=W[wi];rl.replaceChildren(s);s.animate([{opacity:0,transform:"translateY(70%)"},{opacity:1,transform:"none"}],{duration:500,easing:"cubic-bezier(.2,.8,.2,1)"})},2400);
/* copy email */
$("#cp").addEventListener("click",async()=>{const s=$("#cp span");try{await navigator.clipboard.writeText("hello@bhaveshcharan.com");s.textContent="Copied"}catch(e){location.href="mailto:hello@bhaveshcharan.com"}setTimeout(()=>s.textContent="Copy email",1800)});

/* hunt stepper */
const P=[
{t:"Scope and rules",s:"Read the policy before sending a single request.",l:["In-scope and out-of-scope assets, plus safe-harbor terms","Allowed vulnerability classes, rate limits and testing rules","Bounty table, severity guidance and disclosure terms"],g:["HackerOne","Bugcrowd","Program policy"],o:"a written scope checklist"},
{t:"Passive recon",s:"Learn the target without touching it.",l:["Subdomains from certificate transparency and DNS records","Historical URLs and leaked endpoints from web archives","Public code, docs and portals found with search dorks"],g:["subfinder","amass","crt.sh","gau","GitHub dorks","Shodan"],o:"an asset inventory"},
{t:"Active discovery",s:"Find what is alive and what it runs.",l:["Resolve hosts, then probe ports and services","Fingerprint frameworks, servers and WAFs","Screenshot every web app to triage by eye"],g:["httpx","Nmap","naabu","WhatWeb","gowitness"],o:"live hosts with a technology map"},
{t:"Content and endpoints",s:"Map every route and parameter.",l:["Fuzz directories, files and virtual hosts","Mine JavaScript for endpoints, keys and API routes","Find hidden parameters, OpenAPI docs and GraphQL schemas"],g:["ffuf","feroxbuster","katana","Arjun","LinkFinder"],o:"an endpoint and parameter map"},
{t:"Understand the app",s:"Learn how it is supposed to work before breaking it.",l:["Create accounts for every role and compare what each can do","Trace login, session, password reset and invite flows","Note trust boundaries, payments and multi-step business flows"],g:["Burp Suite","Autorize","Proxy history"],o:"a role and permission matrix"},
{t:"Test by category",s:"Work through the OWASP Top 10 and the WSTG methodically.",l:["Broken Access Control: IDOR, privilege escalation, forced browsing, SSRF","Injection: SQLi, XSS, command and template injection, plus file upload","Authentication Failures, business logic, race conditions and API flaws (BOLA)"],g:["Burp Repeater","Intruder","sqlmap","Nuclei","OWASP WSTG"],o:"a shortlist of candidate findings"},
{t:"Validate and rate",s:"Prove it, keep it safe, measure the impact.",l:["Reproduce it reliably with a minimal, non-destructive PoC","Rule out duplicates, false positives and self-only impact","Try chaining bugs, then score with CVSS and map to a CWE"],g:["CVSS","CWE","PoC"],o:"a verified finding with a severity"},
{t:"Report and follow up",s:"Make it easy for the triager to say yes.",l:["Title, summary, numbered steps, PoC, impact and remediation advice","Answer triage questions quickly and politely","Retest after the fix and disclose only when the program allows"],g:["Report template","Retest","Responsible disclosure"],o:"a triaged report and a closed loop"}];
const pl=$("#pl"),pp=$("#pp"),mk=(t,c,x)=>{const e=d.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const sel=i=>{[...pl.children].forEach((b,j)=>b.setAttribute("aria-selected",j===i));const p=P[i],u=mk("ul");p.l.forEach(x=>u.append(mk("li",0,x)));const g=mk("div","tags");p.g.forEach(x=>g.append(mk("span",0,x)));pp.replaceChildren(mk("h3",0,p.t),mk("p","ps",p.s),u,g,mk("div","out","Output: "+p.o))};
P.forEach((p,i)=>{const b=mk("button");b.type="button";b.setAttribute("role","tab");b.append(mk("em",0,String(i+1).padStart(2,"0")),p.t);b.addEventListener("click",()=>sel(i));
b.addEventListener("keydown",e=>{const k=e.key==="ArrowDown"?1:e.key==="ArrowUp"?-1:0;if(k){e.preventDefault();const j=(i+k+P.length)%P.length;sel(j);pl.children[j].focus()}});pl.append(b)});sel(0);
/* hardening checklists */
const CK={"Linux server":["Disable root SSH login and use key-based auth","Default-deny firewall with ufw or nftables","Install fail2ban against brute force","Enable unattended security updates","Limit sudo to named admins (least privilege)","Disable unused services with systemctl","Enable auditd and ship logs off the host","Test backups with a real restore"],"Windows Server":["Patch through WSUS or Windows Update","Enable BitLocker on all drives","Disable SMBv1 and legacy protocols","Randomise local admin passwords with LAPS","Require NLA and restrict RDP access","Enable Defender Firewall on all profiles","Turn on advanced audit policy and Sysmon","Use tiered admin accounts"]};
for(const[n,it]of Object.entries(CK)){const c=mk("div","card rv"),ct=mk("span","cnt"),p=mk("div","prog"),b=mk("i");p.append(b);c.append(mk("h3",0,n+" hardening"),ct,p);
const up=()=>{const k=c.querySelectorAll("input:checked").length;ct.textContent=k+" / "+it.length+" done";b.style.width=k/it.length*100+"%"};
it.forEach(x=>{const l=mk("label"),i=mk("input");i.type="checkbox";i.addEventListener("change",up);l.append(i,x);c.append(l)});up();$("#ck").append(c);rm?c.classList.add("in"):io.observe(c)}
/* terminal */
const to=$("#to"),ti=$("#ti"),qk=$("#qk"),H=[];let hi=0,q=Promise.resolve();
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const line=t=>{const m=/^([+!#>]) ([\s\S]*)$/.exec(t),e=d.createElement("div");if(m){e.className={"+":"o","!":"w","#":"dm",">":"cm"}[m[1]];e.textContent=m[2]}else e.textContent=t;to.appendChild(e);to.scrollTop=to.scrollHeight};
const OW=["Broken Access Control","Security Misconfiguration","Software Supply Chain Failures","Cryptographic Failures","Injection","Insecure Design","Authentication Failures","Software or Data Integrity Failures","Security Logging & Alerting Failures","Mishandling of Exceptional Conditions"];
const S={"":["+ web       access control, injection, SSRF, logic flaws, API security","+ windows   AD DS, DNS, DHCP, IIS, Hyper-V, GPO, WSUS, RDS, NPS, AD CS","+ linux     OpenSSH, Apache, Nginx, Samba, BIND, Postfix, Docker, systemd","+ network   Nmap, Wireshark, Metasploit, Responder, Impacket, BloodHound","# details: skills web | windows | linux | network"],
web:["# web application security","+ Broken Access Control   IDOR, privilege escalation, forced browsing","+ Injection               SQLi, XSS, command and template injection","+ Server-side             SSRF, XXE, file upload, path traversal","+ Authentication Failures session handling, JWT, password reset flows","+ Logic and API           business logic, race conditions, BOLA","# standards: OWASP Top 10, WSTG, API Top 10, CWE, CVSS"],
windows:["# windows server roles and services","+ identity   AD DS, AD CS, AD FS, Group Policy","+ network    DNS, DHCP, NPS, Routing and Remote Access","+ files      File and Storage Services, DFS, Print Server","+ apps       IIS, Remote Desktop Services, Hyper-V","+ ops        WSUS, WDS, Failover Clustering, Server Backup","+ manage     PowerShell, WinRM, Admin Center, Event Viewer"],
linux:["# linux servers and services","+ web        Apache, Nginx","+ data       MariaDB, MySQL, PostgreSQL","+ network    BIND, ISC DHCP, Squid, OpenVPN, WireGuard","+ files      Samba, NFS, vsftpd","+ mail       Postfix, Dovecot","+ platform   Docker, KVM, systemd, cron, LVM, RAID","+ security   ufw, nftables, fail2ban, auditd, SELinux, AppArmor"],
network:["# network pentesting","+ scan       Nmap, Masscan, Netcat","+ enum       enum4linux, SMBMap, snmpwalk, dnsrecon","+ exploit    Metasploit, Hydra, John, Hashcat","+ internal   Responder, Impacket, NetExec, BloodHound","+ sniff      Wireshark, tcpdump, Bettercap","+ pivot      Chisel, Proxychains","+ wireless   Aircrack-ng   |   vuln scan: Nessus, OpenVAS"]};
const CMD={
help:()=>["# commands (Tab completes, arrow keys give history)","whoami        who I am","about         short bio","skills [x]    web | windows | linux | network","owasp         OWASP Top 10:2025","hunt          my bug bounty workflow","headers       security headers this site ships","scan demo     simulated nmap scan","ls, cat <f>   browse files","contact       email","socials       profiles","blog          writing","clear         clear the screen"],
whoami:()=>["+ Bhavesh Charan","role       security researcher and sysadmin","location   Indore, India","focus      web app security, bug bounty, Linux and Windows admin, network pentest","community  founder of DevAdda"],
about:()=>["I test web apps and networks, run Linux and Windows servers, and write down what I learn.","I follow responsible disclosure: stay in scope, cause no harm, report privately."],
skills:a=>S[a]||["! unknown category: "+a,"# try: skills web | windows | linux | network"],
owasp:()=>["# OWASP Top 10:2025",...OW.map((n,i)=>"A"+String(i+1).padStart(2,"0")+"  "+n)],
hunt:()=>["# my workflow",...P.map((p,i)=>(i+1)+". "+p.t),"# details in the Hunt section below"],
headers:()=>["# security headers this site ships with","+ Content-Security-Policy      default-src 'self'; frame-ancestors 'none'","+ Strict-Transport-Security    max-age=63072000; preload","+ X-Content-Type-Options       nosniff","+ Referrer-Policy              strict-origin-when-cross-origin","+ Permissions-Policy           camera=(), microphone=(), geolocation=()","+ Cross-Origin-Opener-Policy   same-origin","# no cookies, no trackers, static files only"],
scan:a=>a==="demo"?["# simulated output, no real host is scanned","> $ nmap -sV demo.lab","Starting Nmap scan on demo.lab (10.0.0.5)","PORT      STATE     SERVICE  VERSION","22/tcp    open      ssh      OpenSSH","80/tcp    open      http     nginx","443/tcp   open      https    nginx","3306/tcp  filtered  mysql","+ the database port is filtered, so it is not exposed","# Nmap done: 1 IP address (1 host up)"]:["! usage: scan demo","# only a simulated target is available here"],
contact:()=>["mail   hello@bhaveshcharan.com","# or jump to the Contact section"],
socials:()=>["linkedin    linkedin.com/in/bhaveshcharan","github      github.com/bhaveshh","hackerone   hackerone.com/bhaveshh","bugcrowd    bugcrowd.com/bhaveshh","tryhackme   tryhackme.com/p/bhaveshh"],
blog:()=>["# sample posts, real writing is on the way","Why I started writing about security","Hardening a fresh Linux server","IDOR: the bug hiding in plain sight"],
ls:()=>["about.txt  skills.md  hunt.md  flag.txt"],
cat:a=>({"about.txt":CMD.about(),"skills.md":S[""],"hunt.md":CMD.hunt(),"flag.txt":["+ FLAG{welcome_to_bhavesh_sec}"]})[a]||["! cat: "+(a||"missing file")+": no such file"],
sudo:()=>["! bhavesh is not in the sudoers file. This incident will be reported."]};
const run=v=>{v=v.trim();if(!v)return;H.push(v);hi=H.length;const p=v.split(/\s+/),k=p[0].toLowerCase(),a=p.slice(1).join(" ").toLowerCase();
q=q.then(async()=>{line("> $ "+v);if(k==="clear"){to.textContent="";return}const f=Object.hasOwn(CMD,k)?CMD[k]:null,out=f?f(a):["! command not found: "+p[0],"# type help"];for(const t of out){line(t);if(!rm)await sleep(24)}})};
ti.addEventListener("keydown",e=>{if(e.key==="Enter"){run(ti.value);ti.value=""}
else if(e.key==="ArrowUp"&&H.length){hi=Math.max(0,hi-1);ti.value=H[hi];e.preventDefault()}
else if(e.key==="ArrowDown"){hi=Math.min(H.length,hi+1);ti.value=H[hi]||"";e.preventDefault()}
else if(e.key==="Tab"){e.preventDefault();const v=ti.value.toLowerCase(),m=v?Object.keys(CMD).filter(c=>c.startsWith(v)):[];if(m.length===1)ti.value=m[0]}});
$("#term").addEventListener("click",e=>{if(!e.target.closest("button"))ti.focus({preventScroll:true})});
["whoami","skills","owasp","hunt","headers","scan demo","help"].forEach(c=>{const b=mk("button",0,c);b.type="button";b.addEventListener("click",()=>run(c));qk.append(b)});
line("# bhavesh.sec shell. Type help, or tap a command below.");run("whoami");
})();
