
(()=>{const d=document,$=s=>d.querySelector(s),$$=s=>[...d.querySelectorAll(s)],rm=matchMedia("(prefers-reduced-motion: reduce)").matches;
const y=$("#y");if(y)y.textContent=new Date().getFullYear();
/* menu */
const nb=$("#nbt"),nv=$("#nv"),hd=$("header");
const setM=o=>{nv.classList.toggle("open",o);nb.classList.toggle("on",o);nb.setAttribute("aria-expanded",o);d.body.classList.toggle("lock",o)};
nb.addEventListener("click",()=>setM(!nv.classList.contains("open")));
nv.addEventListener("click",e=>{if(e.target.closest("a"))setM(false)});
addEventListener("keydown",e=>{if(e.key==="Escape")setM(false)});
matchMedia("(min-width:861px)").addEventListener("change",()=>setM(false));
/* scroll progress */
const bar=$("#bar"),onS=()=>{const h=d.documentElement,m=h.scrollHeight-h.clientHeight;bar.style.width=(m>0?h.scrollTop/m*100:0)+"%";hd.classList.toggle("sc",h.scrollTop>20)};
addEventListener("scroll",onS,{passive:true});onS();
/* reveal + counters */
const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add("in");io.unobserve(x.target)}}),{threshold:.12});
$$(".rv").forEach(el=>rm?el.classList.add("in"):io.observe(el));
const co=new IntersectionObserver(es=>es.forEach(x=>{if(!x.isIntersecting)return;co.unobserve(x.target);const el=x.target,n=+el.dataset.n;if(rm||!n){el.textContent=n;return}let t0;const st=t=>{t0=t0||t;const p=Math.min((t-t0)/1200,1);el.textContent=Math.round(n*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(st)};requestAnimationFrame(st)}));
$$("[data-n]").forEach(el=>co.observe(el));
/* scroll spy */
const ln=$$("#nv a[href*='#']"),so=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting)ln.forEach(a=>a.classList.toggle("act",a.getAttribute("href").endsWith("#"+x.target.id)))}),{rootMargin:"-45% 0px -50% 0px"});
$$("main section[id]").forEach(s=>so.observe(s));
/* cursor glow */
const gl=$("#gl");addEventListener("pointermove",e=>{gl.style.transform="translate("+e.clientX+"px,"+e.clientY+"px)"},{passive:true});
/* card tilt + spotlight */
$$(".tilt").forEach(c=>{c.addEventListener("pointermove",e=>{if(e.pointerType!=="mouse")return;const r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;c.style.setProperty("--mx",x*100+"%");c.style.setProperty("--my",y*100+"%");if(!rm){c.style.setProperty("--rx",((.5-y)*6).toFixed(2)+"deg");c.style.setProperty("--ry",((x-.5)*8).toFixed(2)+"deg")}});
c.addEventListener("pointerleave",()=>{c.style.setProperty("--rx","0deg");c.style.setProperty("--ry","0deg")})});
/* magnetic buttons */
if(!rm)$$(".mag").forEach(b=>{b.addEventListener("pointermove",e=>{if(e.pointerType!=="mouse")return;const r=b.getBoundingClientRect();b.style.transform="translate("+((e.clientX-r.left-r.width/2)*.18)+"px,"+((e.clientY-r.top-r.height/2)*.3)+"px)"});b.addEventListener("pointerleave",()=>{b.style.transform=""})});
})();
