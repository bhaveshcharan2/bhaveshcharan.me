# bhaveshcharan.com

Static portfolio and blog. No cookies, no trackers, no third-party requests. Fonts are self-hosted.

## Structure
- `public/`  the website. Deploy this folder.
- `posts/`   blog posts as markdown files.
- `build.py` generates blog pages, 404, sitemap.xml, rss.xml and the latest posts on the home page.
- `vercel.json`, `netlify.toml`, `nginx.conf.example`, `public/_headers`, `public/.htaccess`  security headers and hosting config.

## Preview locally
```
python3 build.py
python3 -m http.server 8000 -d public
```
Open http://localhost:8000 (use a server, not a double-click, because the site uses absolute paths).

## Add a blog post
1. Create `posts/my-post.md`:
```
---
title: My post title
date: 2026-11-01
description: One or two sentences, 120 to 155 characters, shown in Google and social previews.
tags: web-security, owasp
---
## Heading

Text, `inline code`, **bold**, [links](https://example.com), lists and ``` code blocks.
```
2. Run `python3 build.py`, then deploy again. Add `draft: true` to hide a post. Add `updated: 2026-11-05` after an edit.

## Before going live (edit these)
- `public/index.html`: social profile URLs (search for `bhaveshh` and `bhaveshcharan`), the stat numbers (`data-n="0"`), and the JSON-LD `sameAs` list.
- `public/.well-known/security.txt`: renew the `Expires` date every year.
- The three starter posts in `posts/` are generic. Edit or delete them.
- Domain is set to https://bhaveshcharan.com in `build.py` (`S = ...`). Change it there if needed.

## Deploy (pick one)
- **Cloudflare Pages / Netlify**: output directory `public`. `_headers` is applied automatically.
- **Vercel**: import the repo, `vercel.json` sets output directory and headers. Commit the built `public/` folder.
- **Apache**: upload `public/` contents (includes `.htaccess`, needs mod_headers).
- **Nginx**: start from `nginx.conf.example`.
- **GitHub Pages does not support custom headers**, so the security headers will not apply there.

## After deploy
1. Test headers: https://securityheaders.com and https://observatory.mozilla.org
2. Add the site to Google Search Console and Bing Webmaster Tools, and submit `https://bhaveshcharan.com/sitemap.xml`.
3. Check social previews and structured data: https://search.google.com/test/rich-results
4. HSTS `preload` is in the headers. Only submit to hstspreload.org when HTTPS works on the domain and all subdomains.

## Security notes
- Strict Content-Security-Policy: scripts, styles, fonts and images only from the same origin, no inline code.
- Also sent: HSTS, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy, COOP, CORP.
- No forms, no cookies, no backend. Contact is a mailto link.
- Do not add inline `<script>`, `<style>` or `style=""` attributes, they will be blocked by the CSP. Put code in `assets/js` and `assets/css`.
