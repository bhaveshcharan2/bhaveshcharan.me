#!/usr/bin/env python3
"""Static site builder.  Usage:  python3 build.py
Reads posts/*.md and writes blog pages, the blog index, latest posts on the home page,
404.html, sitemap.xml and rss.xml into public/.  No dependencies."""
import re, html, json, pathlib, datetime

R = pathlib.Path(__file__).parent
P = R / "public"
S = "https://bhaveshcharan.com"
NAME = "Bhavesh Charan"
e = html.escape

ICONS = ('<link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="icon" href="/favicon.ico" sizes="48x48">'
         '<link rel="icon" href="/assets/img/favicon-32.png" type="image/png" sizes="32x32">'
         '<link rel="apple-touch-icon" href="/assets/img/apple-touch-icon.png"><link rel="manifest" href="/site.webmanifest">'
         f'<link rel="alternate" type="application/rss+xml" title="{NAME} Blog" href="/rss.xml">'
         '<link rel="sitemap" type="application/xml" href="/sitemap.xml">')

def ld(o):
    return '<script type="application/ld+json">' + json.dumps(o, ensure_ascii=False).replace("</", "<\\/") + "</script>"

def head(title, desc, path, typ="website", data=None, extra="", robots="index,follow,max-image-preview:large,max-snippet:-1"):
    u = S + path
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{e(title)}</title><meta name="description" content="{e(desc)}"><meta name="author" content="{NAME}">
<meta name="robots" content="{robots}"><meta name="theme-color" content="#07080c"><meta name="color-scheme" content="dark">
<link rel="canonical" href="{u}">
{ICONS}
<meta property="og:type" content="{typ}"><meta property="og:site_name" content="{NAME}"><meta property="og:locale" content="en_IN">
<meta property="og:title" content="{e(title)}"><meta property="og:description" content="{e(desc)}"><meta property="og:url" content="{u}">
<meta property="og:image" content="{S}/assets/img/og.png"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="{NAME}, cybersecurity researcher">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{e(title)}"><meta name="twitter:description" content="{e(desc)}"><meta name="twitter:image" content="{S}/assets/img/og.png">
{extra}<link rel="preload" href="/assets/fonts/hanken-grotesk-400.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/assets/css/style.css">
{ld(data) if data else ""}</head><body>'''

def slug(t):
    return re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-")

def inline(t):
    t = e(t, quote=False)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    return re.sub(r"\[([^\]]+)\]\((https?://[^)\s]+|/[^)\s]*)\)",
                  lambda m: '<a href="%s"%s>%s</a>' % (m[2], ' rel="noopener noreferrer" target="_blank"' if m[2].startswith("http") else "", m[1]), t)

def md(src):
    out, code, lst = [], None, None
    def close():
        nonlocal lst
        if lst: out.append(f"</{lst}>"); lst = None
    for l in src.split("\n"):
        if l.startswith("```"):
            if code is None: close(); code = []
            else: out.append("<pre><code>" + e("\n".join(code)) + "</code></pre>"); code = None
            continue
        if code is not None: code.append(l); continue
        m = re.match(r"(- |\d+\. )(.*)", l)
        if m:
            t = "ul" if m[1] == "- " else "ol"
            if lst != t: close(); out.append(f"<{t}>"); lst = t
            out.append("<li>" + inline(m[2]) + "</li>"); continue
        close()
        if l.startswith("### "): out.append("<h3>" + inline(l[4:]) + "</h3>")
        elif l.startswith("## "): out.append(f'<h2 id="{slug(l[3:])}">' + inline(l[3:]) + "</h2>")
        elif l.startswith("> "): out.append("<blockquote><p>" + inline(l[2:]) + "</p></blockquote>")
        elif l.strip(): out.append("<p>" + inline(l) + "</p>")
    close()
    return "\n".join(out)

def fdate(d):
    return datetime.date.fromisoformat(d).strftime("%d %b %Y").lstrip("0")

def write(rel, txt):
    p = P / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(txt, encoding="utf-8")

def main():
    idx = (P / "index.html").read_text(encoding="utf-8")
    PRE = re.search(r"<body>(.*?)<main", idx, re.S).group(1)
    FOOT = re.search(r"<footer>.*?</footer>", idx, re.S).group(0)
    TAIL = '<script src="/assets/js/main.js" defer></script></body></html>'

    posts = []
    for f in sorted((R / "posts").glob("*.md")):
        m = re.match(r"---\n(.*?)\n---\n(.*)", f.read_text(encoding="utf-8"), re.S)
        meta = dict(x.split(": ", 1) for x in m[1].split("\n") if ": " in x)
        if meta.get("draft", "").lower() == "true": continue
        meta.update(slug=f.stem, body=m[2], mins=max(1, round(len(m[2].split()) / 200)))
        meta["mod"] = meta.get("updated", meta["date"])
        posts.append(meta)
    posts.sort(key=lambda p: (p["date"], p["slug"]), reverse=True)

    def pcard(p):
        return (f'<a class="card tilt rv" href="/blog/{p["slug"]}/"><time datetime="{p["date"]}">{fdate(p["date"])}</time>'
                f'<h3>{e(p["title"])}</h3><p>{e(p["description"])}</p></a>')

    for i, p in enumerate(posts):
        u = f'/blog/{p["slug"]}/'
        tags = "".join(f"<span>{e(t.strip())}</span>" for t in p.get("tags", "").split(",") if t.strip())
        nxt = posts[i - 1] if i > 0 else None
        prv = posts[i + 1] if i + 1 < len(posts) else None
        pn = "".join(f'<a class="card" href="/blog/{q["slug"]}/"><time>{lab}</time><h3>{e(q["title"])}</h3></a>' for lab, q in (("Older", prv), ("Newer", nxt)) if q)
        data = {"@context": "https://schema.org", "@graph": [
            {"@type": "BlogPosting", "headline": p["title"], "description": p["description"], "datePublished": p["date"], "dateModified": p["mod"],
             "image": S + "/assets/img/og.png", "inLanguage": "en", "mainEntityOfPage": S + u,
             "author": {"@type": "Person", "name": NAME, "url": S + "/"}, "publisher": {"@type": "Person", "name": NAME, "url": S + "/"},
             "keywords": p.get("tags", "")},
            {"@type": "BreadcrumbList", "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Home", "item": S + "/"},
                {"@type": "ListItem", "position": 2, "name": "Blog", "item": S + "/blog/"},
                {"@type": "ListItem", "position": 3, "name": p["title"], "item": S + u}]}]}
        body = (f'<main id="top"><article class="post"><nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><a href="/blog/">Blog</a></nav>'
                f'<h1>{e(p["title"])}</h1><p class="meta"><time datetime="{p["date"]}">{fdate(p["date"])}</time> &middot; {p["mins"]} min read</p>'
                f'<div class="prose">{md(p["body"])}</div><div class="tags">{tags}</div><div class="pn">{pn}</div></article></main>')
        write(f'blog{u[5:]}index.html', head(f'{p["title"]} | {NAME}', p["description"], u, "article", data) + PRE + body + FOOT + TAIL)

    data = {"@context": "https://schema.org", "@type": "Blog", "name": f"{NAME} Blog", "url": S + "/blog/", "inLanguage": "en",
            "author": {"@type": "Person", "name": NAME, "url": S + "/"},
            "blogPost": [{"@type": "BlogPosting", "headline": p["title"], "url": f'{S}/blog/{p["slug"]}/', "datePublished": p["date"]} for p in posts]}
    body = (f'<main id="top"><div class="post"><nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span>/</span><span>Blog</span></nav>'
            f'<h1>Blog</h1><p class="meta">Security writeups, hardening guides and bug bounty notes. <a href="/rss.xml">RSS feed</a></p>'
            f'<div class="blist">{"".join(pcard(p) for p in posts)}</div></div></main>')
    write("blog/index.html", head(f"Blog: Security Writeups and Hardening Guides | {NAME}", "Security writeups, Linux and Windows hardening guides and bug bounty notes from Bhavesh Charan, a cybersecurity researcher in India.", "/blog/", "website", data) + PRE + body + FOOT + TAIL)

    write("404.html", head(f"Page not found | {NAME}", "This page does not exist.", "/404.html", robots="noindex,nofollow") + PRE +
          '<main id="top" class="nf"><h1 class="ht">404</h1><p>This page does not exist or has moved.</p><div><a class="btn p" href="/">Back to home</a></div></main>' + FOOT + TAIL)

    new = re.sub(r"<!--POSTS-->.*?<!--/POSTS-->", lambda m: "<!--POSTS-->" + "".join(pcard(p) for p in posts[:3]) + "<!--/POSTS-->", idx, flags=re.S)
    (P / "index.html").write_text(new, encoding="utf-8")

    last = max([p["mod"] for p in posts] + [datetime.date.today().isoformat()])
    urls = [("/", last, "1.0"), ("/blog/", last, "0.8")] + [(f'/blog/{p["slug"]}/', p["mod"], "0.7") for p in posts]
    write("sitemap.xml", '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' +
          "".join(f"<url><loc>{S}{u}</loc><lastmod>{d}</lastmod><priority>{pr}</priority></url>" for u, d, pr in urls) + "</urlset>\n")
    rfc = lambda d: datetime.datetime.strptime(d, "%Y-%m-%d").strftime("%a, %d %b %Y 00:00:00 +0000")
    write("rss.xml", f'<?xml version="1.0" encoding="UTF-8"?>\n<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom"><channel><title>{NAME} Blog</title><link>{S}/blog/</link>'
          f'<description>Security writeups, hardening guides and bug bounty notes.</description><language>en</language><atom:link href="{S}/rss.xml" rel="self" type="application/rss+xml"/>' +
          "".join(f'<item><title>{e(p["title"])}</title><link>{S}/blog/{p["slug"]}/</link><guid>{S}/blog/{p["slug"]}/</guid><pubDate>{rfc(p["date"])}</pubDate><description>{e(p["description"])}</description></item>' for p in posts) +
          "</channel></rss>\n")
    print(f"Built {len(posts)} post(s), blog index, 404, sitemap.xml, rss.xml")

if __name__ == "__main__":
    main()
