---
title: Hardening a fresh Linux server in ten minutes
date: 2026-10-22
description: A short checklist for a new Ubuntu or Debian server: non-root user, SSH key login, default-deny firewall, fail2ban and automatic security updates.
tags: linux, hardening
---
A new server on the internet gets probed within minutes. These steps cover the basics on Ubuntu or Debian. Keep your current SSH session open until you have tested the new login.

## 1. Create a non-root admin user

```bash
adduser deploy
usermod -aG sudo deploy
```

## 2. Use SSH keys and turn off root login

Copy your public key to the new user with `ssh-copy-id`, then edit the SSH daemon config.

```text
# /etc/ssh/sshd_config
PermitRootLogin no
PasswordAuthentication no
```

```bash
sudo systemctl reload ssh
```

On Red Hat based systems the service is called `sshd`.

## 3. Turn on a default-deny firewall

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow OpenSSH
sudo ufw enable
```

## 4. Block brute force and patch automatically

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y fail2ban unattended-upgrades
```

## 5. Verify

- Open a second terminal and log in as the new user with your key
- Run `sudo ufw status verbose` and check only the ports you need are open
- Run `sudo fail2ban-client status` to confirm the jail is active

This is a starting point, not a full hardening standard. Next steps are auditd, log shipping and tested backups.
