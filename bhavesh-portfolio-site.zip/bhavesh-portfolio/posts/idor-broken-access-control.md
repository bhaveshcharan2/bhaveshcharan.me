---
title: IDOR explained: broken access control
date: 2026-10-22
description: What an IDOR is, how to test for it safely with two accounts, and how developers fix it. Maps to OWASP A01:2025 Broken Access Control.
tags: web-security, owasp
---
An Insecure Direct Object Reference (IDOR) happens when an application uses an identifier from the user, such as an ID in a URL, and returns the object without checking that the user is allowed to see it. It sits under **Broken Access Control**, the number one category in the OWASP Top 10:2025, and maps to CWE-639.

## A simple example

You open your invoice at `/api/invoices/1042`. If changing the number to `1043` shows someone else's invoice, the server is trusting the ID and skipping the ownership check.

## How to test it safely

- Use two test accounts that you own, never real users
- Capture a request from account A that references an object ID
- Replay it with account B's session and compare the response
- Check other methods too: read, update and delete can be protected differently
- Stay inside the program scope and stop as soon as you have proof

## How developers fix it

- Check authorization on the server for every request, not just at login
- Look the object up through the current user, for example "invoices where id and owner match"
- Use a central access control layer instead of per-endpoint checks
- Unpredictable IDs such as UUIDs help, but they are defense in depth, not a fix

## Reporting it

Show two accounts, the exact request, the response that should have been denied, and the impact. Suggest the ownership check as the fix.
