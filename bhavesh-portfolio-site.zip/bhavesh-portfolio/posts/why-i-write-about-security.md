---
title: Why I write about security
date: 2026-10-22
description: Why this blog exists and what to expect: bug bounty notes, Linux and Windows hardening guides, OWASP-mapped web security writeups and CTF notes.
tags: meta, bug-bounty
---
## Writing is how I learn

I learn security fastest when I have to explain it. This blog is where I write down what I test, break and fix, so I can find it again and so others can too.

## What you will find here

- Web application security notes, mapped to the OWASP Top 10
- Linux and Windows server hardening guides
- Bug bounty methodology and report-writing tips
- CTF writeups once I have them to share

> Only test systems you own or have written permission to test.

## Staying in the rules

Everything here follows responsible disclosure: stay in scope, avoid harming users or data, and report privately so the owner can fix the issue first.
